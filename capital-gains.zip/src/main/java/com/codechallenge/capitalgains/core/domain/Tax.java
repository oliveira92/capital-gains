package com.codechallenge.capitalgains.core.domain;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Tax {

    private double tax;

}
